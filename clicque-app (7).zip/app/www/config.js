// Fill these two values from Supabase: Project Settings > API.
// The anon key is meant to be public; security comes from the row-level rules in supabase/schema.sql.
window.CLICQUE_CONFIG={
  SUPABASE_URL:'https://YOUR-PROJECT.supabase.co',
  SUPABASE_ANON_KEY:'YOUR-ANON-KEY'
};
